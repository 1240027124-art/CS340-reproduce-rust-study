use crate::{c_str::CStr, header::stdlib::getenv, platform::types::c_char};
use syscall::{EIO, ENOENT, Error, Result, flag::O_SYMLINK};

pub const LIBC_SCHEME: &str = "/scheme/libc";

const ENV_MAX_LEN: i32 = i32::MAX;

macro_rules! env_str {
    ($lit:expr) => {
        #[allow(unused_unsafe)]
        {
            let val_bytes = unsafe { getenv(concat!($lit, "\0").as_ptr().cast::<c_char>()) };
            if val_bytes.is_null() {
                None
            } else if let Ok(val_str) = unsafe { CStr::from_ptr(val_bytes) }.to_str() {
                Some(val_str)
            } else {
                None
            }
        }
    };
}

pub fn open(path: &str, flags: usize) -> Result<usize> {
    assert!(path.starts_with(LIBC_SCHEME));

    if flags & O_SYMLINK != 0 {
        return Err(Error::new(ENOENT));
    }

    let basename = match path.strip_prefix(LIBC_SCHEME) {
        Some(path) => path.trim_matches('/'),
        _ => return Err(Error::new(EIO)),
    };

    // Linux seems to allow you to read from or write to any of /dev/{stdin,stderr,stdout}
    match basename {
        "stderr" => redox_rt::sys::dup(2, &[]),
        "stdin" => redox_rt::sys::dup(0, &[]),
        "stdout" => redox_rt::sys::dup(1, &[]),
        "tty" => {
            if let Some(tty) = env_str!("TTY") {
                return redox_rt::sys::open(tty, flags);
            }
            Err(Error::new(ENOENT))
        }
        _ => Err(Error::new(ENOENT)),
    }
}
