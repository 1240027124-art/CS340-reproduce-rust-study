//! `time.h` implementation.
//!
//! See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/time.h.html>.

use crate::{
    c_str::{CStr, CString},
    error::{Errno, ResultExt},
    header::{
        errno::{EINVAL, ENOMEM, EOVERFLOW, ETIMEDOUT},
        signal::sigevent,
        stdlib,
        time::posix_tz::PosixTz,
        unistd::readlink,
    },
    out::Out,
    platform::{
        self, Pal, Sys,
        types::{
            c_char, c_double, c_int, c_long, clock_t, clockid_t, pid_t, size_t, time_t, timer_t,
        },
    },
    raw_cell::RawCell,
    sync::{Mutex, MutexGuard},
};
use alloc::collections::BTreeSet;
use chrono::{
    DateTime, Datelike, NaiveDate, NaiveDateTime, Offset, TimeZone, Timelike, Utc,
    offset::MappedLocalTime,
};
use chrono_tz::{OffsetComponents, OffsetName, Tz};
use core::{cell::OnceCell, convert::TryFrom, mem, ptr};

pub use crate::header::bits_timespec::timespec;

pub use self::constants::*;

pub mod constants;

mod posix_tz;
mod strftime;
mod strptime;
pub use strptime::strptime;

/// cbindgen:ignore
const YEARS_PER_ERA: time_t = 400;
/// cbindgen:ignore
const DAYS_PER_ERA: time_t = 146097;
/// cbindgen:ignore
const SECS_PER_DAY: time_t = 24 * 60 * 60;
/// cbindgen:ignore
pub(crate) const NANOSECONDS: c_long = 1_000_000_000;
/// cbindgen:ignore
const UTC_STR: &core::ffi::CStr = c"UTC";

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/time.h.html>.
#[repr(C)]
pub struct tm {
    pub tm_sec: c_int,          // 0 - 60
    pub tm_min: c_int,          // 0 - 59
    pub tm_hour: c_int,         // 0 - 23
    pub tm_mday: c_int,         // 1 - 31
    pub tm_mon: c_int,          // 0 - 11
    pub tm_year: c_int,         // years since 1900
    pub tm_wday: c_int,         // 0 - 6 (Sunday - Saturday)
    pub tm_yday: c_int,         // 0 - 365
    pub tm_isdst: c_int,        // >0 if DST, 0 if not, <0 if unknown
    pub tm_gmtoff: c_long,      // offset from UTC in seconds
    pub tm_zone: *const c_char, // timezone abbreviation
}

unsafe impl Sync for tm {}

/// cbindgen:ignore
// The C Standard says that localtime and gmtime return the same pointer.
static GMTIME_LOCALTIME_RETURN_TM: RawCell<tm> = RawCell::new(blank_tm());

/// cbindgen:ignore
// The C Standard says that ctime and asctime return the same pointer.
static mut ASCTIME: [c_char; 26] = [0; 26];

#[repr(transparent)]
pub struct TzName([*mut c_char; 2]);

unsafe impl Sync for TzName {}

/// cbindgen:ignore
// Name storage for the `tm_zone` field.
static TIMEZONE_NAMES: Mutex<OnceCell<BTreeSet<CString>>> = Mutex::new(OnceCell::new());

/// cbindgen:ignore
// relibc functions should hold `TIMEZONE_LOCK` when accessing `daylight`,
// `timezone`, and `tzname`. However, it cannot guard those variables against
// user access (see `tzset()` specs for details).
static TIMEZONE_LOCK: Mutex<(Option<CString>, Option<CString>)> = Mutex::new((None, None));

// Should only be accessed by relibc when `TIMEZONE_LOCK` is held
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/tzset.html>.
#[unsafe(no_mangle)]
pub static mut daylight: c_int = 0;

// Should only be accessed by relibc when `TIMEZONE_LOCK` is held
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/tzset.html>.
#[unsafe(no_mangle)]
pub static mut timezone: c_long = 0;

// Should only be accessed by relibc when `TIMEZONE_LOCK` is held
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/tzset.html>.
#[unsafe(no_mangle)]
pub static mut tzname: TzName = TzName([ptr::null_mut(); 2]);

#[unsafe(no_mangle)]
pub static mut getdate_err: c_int = 0;

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/time.h.html>.
#[repr(C)]
#[derive(Clone, Default)]
pub struct itimerspec {
    pub it_interval: timespec,
    pub it_value: timespec,
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/asctime.html>.
///
/// # Deprecation
/// The `asctime()` function was marked obsolescent in the Open Group Base
/// Specifications Issue 7.
#[deprecated]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn asctime(timeptr: *const tm) -> *mut c_char {
    unsafe {
        #[expect(deprecated)]
        asctime_r(timeptr, (&raw mut ASCTIME).cast())
    }
}

/// See <https://pubs.opengroup.org/onlinepubs/9699919799/functions/asctime.html>.
///
/// # Deprecation
/// The `asctime_r()` was marked obsolescent in the Open Group Base
/// Specifications Issue 7, and removed in Issue 8.
#[deprecated]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn asctime_r(tm: *const tm, buf: *mut c_char) -> *mut c_char {
    let tm_sec = unsafe { (*tm).tm_sec };
    let tm_min = unsafe { (*tm).tm_min };
    let tm_hour = unsafe { (*tm).tm_hour };
    let tm_mday = unsafe { (*tm).tm_mday };
    let tm_mon = unsafe { (*tm).tm_mon };
    let tm_year = unsafe { (*tm).tm_year };
    let tm_wday = unsafe { (*tm).tm_wday };

    /* Panic when we run into undefined behavior.
     *
     * POSIX says (since issue 7) that asctime()/asctime_r() cause UB
     * when the tm member values would cause out-of-bounds array access
     * or overflow the output buffer. This contrasts with ISO C11+,
     * which specifies UB for any tm members being outside their normal
     * ranges. While POSIX explicitly defers to the C standard in case
     * of contradictions, the assertions below follow the interpretation
     * that POSIX simply defines some of C's undefined behavior, rather
     * than conflict with the ISO standard.
     *
     * Note that C's "%.2d" formatting, unlike Rust's "{:02}"
     * formatting, does not count a minus sign against the two digits to
     * print, meaning that we must reject all negative values for
     * seconds, minutes and hours. However, C's "%3d" (for day-of-month)
     * is similar to Rust's "{:3}".
     *
     * To avoid year overflow problems (in Rust, where numeric overflow
     * is considered an error), we subtract 1900 from the endpoints,
     * rather than adding to the tm_year value. POSIX' requirement that
     * tm_year be at most {INT_MAX}-1990 is satisfied for all legal
     * values of {INT_MAX} through the max-4-digit requirement on the
     * year.
     *
     * The tm_mon and tm_wday fields are used for array access and thus
     * will already cause a panic in Rust code when out of range.
     * However, using the assertions below allows a consistent error
     * message for all fields. */
    const OUT_OF_RANGE_MESSAGE: &str = "tm member out of range";

    assert!((0..=99).contains(&tm_sec), "{OUT_OF_RANGE_MESSAGE}");
    assert!((0..=99).contains(&tm_min), "{OUT_OF_RANGE_MESSAGE}");
    assert!((0..=99).contains(&tm_hour), "{OUT_OF_RANGE_MESSAGE}");
    assert!((-99..=999).contains(&tm_mday), "{OUT_OF_RANGE_MESSAGE}");
    assert!((0..=11).contains(&tm_mon), "{OUT_OF_RANGE_MESSAGE}");
    assert!(
        (-999 - 1900..=9999 - 1900).contains(&tm_year),
        "{OUT_OF_RANGE_MESSAGE}"
    );
    assert!((0..=6).contains(&tm_wday), "{OUT_OF_RANGE_MESSAGE}");

    // At this point, we can safely use the values as given.
    let write_result = core::fmt::write(
        // buf may be either `*mut u8` or `*mut i8`
        &mut platform::UnsafeStringWriter(buf.cast()),
        format_args!(
            "{:.3} {:.3}{:3} {:02}:{:02}:{:02} {}\n",
            DAY_NAMES[usize::try_from(tm_wday).unwrap()],
            MON_NAMES[usize::try_from(tm_mon).unwrap()],
            tm_mday,
            tm_hour,
            tm_min,
            tm_sec,
            1900 + tm_year
        ),
    );
    match write_result {
        Ok(()) => buf,
        Err(_) => {
            /* asctime()/asctime_r() or the equivalent sprintf() call
             * have no defined errno setting */
            ptr::null_mut()
        }
    }
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock.html>.
#[unsafe(no_mangle)]
pub extern "C" fn clock() -> clock_t {
    let mut ts = mem::MaybeUninit::<timespec>::uninit();

    if unsafe { clock_gettime(CLOCK_PROCESS_CPUTIME_ID, ts.as_mut_ptr()) } != 0 {
        return -1;
    }
    let ts = unsafe { ts.assume_init() };

    #[cfg(target_arch = "x86")]
    let clocks = ts.tv_sec * i64::from(CLOCKS_PER_SEC)
        + i64::from(ts.tv_nsec / (1_000_000_000 / CLOCKS_PER_SEC));
    #[cfg(not(target_arch = "x86"))]
    let clocks = ts.tv_sec * CLOCKS_PER_SEC + (ts.tv_nsec / (1_000_000_000 / CLOCKS_PER_SEC));
    clock_t::try_from(clocks).unwrap_or(-1)
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock_getcpuclockid.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn clock_getcpuclockid(pid: pid_t, clock_id: *mut clockid_t) -> c_int {
    unimplemented!();
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock_getres.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn clock_getres(clock_id: clockid_t, res: *mut timespec) -> c_int {
    Sys::clock_getres(clock_id, unsafe { Out::nullable(res) })
        .map(|()| 0)
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock_getres.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn clock_gettime(clock_id: clockid_t, tp: *mut timespec) -> c_int {
    Sys::clock_gettime(clock_id, unsafe { Out::nonnull(tp) })
        .map(|()| 0)
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock_nanosleep.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn clock_nanosleep(
    clock_id: clockid_t,
    flags: c_int,
    rqtp: *const timespec,
    rmtp: *mut timespec,
) -> c_int {
    unimplemented!();
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/clock_getres.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn clock_settime(clock_id: clockid_t, tp: *const timespec) -> c_int {
    unsafe { Sys::clock_settime(clock_id, tp) }
        .map(|()| 0)
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/ctime.html>.
///
/// # Deprecation
/// The `ctime()` function was marked obsolescent in the Open Group Base
/// Specifications Issue 7.
#[deprecated]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ctime(clock: *const time_t) -> *mut c_char {
    unsafe {
        #[expect(deprecated)]
        asctime(localtime(clock))
    }
}

/// See <https://pubs.opengroup.org/onlinepubs/9699919799/functions/ctime.html>.
///
/// # Deprecation
/// The `ctime_r()` function was marked obsolescent in the Open Group Base
/// Specifications Issue 7, and removed in Issue 8.
#[deprecated]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ctime_r(clock: *const time_t, buf: *mut c_char) -> *mut c_char {
    // Using MaybeUninit<tm> seems to cause a panic during the build process
    let mut tm1 = blank_tm();
    unsafe { localtime_r(clock, &raw mut tm1) };
    unsafe {
        #[expect(deprecated)]
        asctime_r(&raw const tm1, buf)
    }
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/difftime.html>.
///
/// Computes the difference between two calendar time values: `time1` - `time0`
#[expect(clippy::cast_precision_loss, reason = "cannot TryFrom")]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn difftime(time1: time_t, time0: time_t) -> c_double {
    (time1 - time0) as c_double
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/getdate.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub unsafe extern "C" fn getdate(string: *const c_char) -> *const tm {
    unimplemented!();
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/gmtime.html>.
///
/// # Safety
/// The caller is required to ensure that:
/// * `timer` is a valid pointer
/// * the function has exclusive access to the static `tm` structure it
///   returns. This includes avoiding simultaneous calls to this function as
///   well as to [`localtime()`].
#[unsafe(no_mangle)]
pub unsafe extern "C" fn gmtime(timer: *const time_t) -> *mut tm {
    // SAFETY: the caller is required to uphold the safety requirements for
    // `gmtime_r()` in addition to exclusive access to
    // `GMTIME_LOCALTIME_RETURN_TM`.
    unsafe { gmtime_r(timer, GMTIME_LOCALTIME_RETURN_TM.as_mut_ptr()) }
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/gmtime.html>.
///
/// # Safety
/// The caller is required to ensure that:
/// * `timer` is a valid pointer
/// * `result` is convertible to an [`Out<tm>`].
#[unsafe(no_mangle)]
pub unsafe extern "C" fn gmtime_r(timer: *const time_t, result: *mut tm) -> *mut tm {
    // SAFETY: the caller is required to ensure that `timer` is a valid pointer.
    let timer_val = unsafe { *timer };

    // SAFETY: the caller is required to ensure that `result` is convertible
    // to an `Out<tm>`.
    let result_out = unsafe { Out::nonnull(result) };

    let _ = get_localtime(timer_val, result_out);
    result
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/localtime.html>.
///
/// # Safety
/// The caller is required to ensure that:
/// * `timer` is a valid pointer
/// * the function has exclusive access to the static `tm` structure it
///   returns. This implies avoiding simultaneous calls to this function as
///   well as to [`gmtime()`]
/// * the variables [`daylight`], [`timezone`] and [`tzname`] are not accessed
///   by user code for the duration of the call.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn localtime(timer: *const time_t) -> *mut tm {
    // SAFETY: the caller is required to uphold the safety requirements for
    // `localtime_r()` in addition to exclusive access to
    // `GMTIME_LOCALTIME_RETURN_TM`.
    unsafe { localtime_r(timer, GMTIME_LOCALTIME_RETURN_TM.as_mut_ptr()) }
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/localtime.html>.
///
/// # Safety
/// The caller is required to ensure that:
/// * `timer` is a valid pointer
/// * `result` is convertible to an [`Out<tm>`]
/// * the variables [`daylight`], [`timezone`] and [`tzname`] are not accessed
///   by user code for the duration of the call.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn localtime_r(timer: *const time_t, result: *mut tm) -> *mut tm {
    // SAFETY: the caller is required to ensure that `timer` is a valid pointer.
    let timer_val = unsafe { *timer };

    // SAFETY: the caller is required to ensure that `result` is convertible
    // to an `Out<tm>`.
    let result_out = unsafe { Out::nonnull(result) };

    let mut lock = TIMEZONE_LOCK.lock();

    // SAFETY: the caller is required to ensure that `daylight`, `timezone`
    // and `tzname` are not accessed by user code.
    unsafe { clear_timezone(&mut lock) };
    if let (Some(std_time), dst_time) = get_localtime(timer_val, result_out) {
        // SAFETY: the caller is required to ensure that `daylight`,
        // `timezone` and `tzname` are not accessed by user code.
        unsafe { set_timezone(&mut lock, &std_time, dst_time) };
    }
    result
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/mktime.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mktime(timeptr: *mut tm) -> time_t {
    let mut lock = TIMEZONE_LOCK.lock();
    unsafe { clear_timezone(&mut lock) };

    let year = unsafe { (*timeptr).tm_year } + 1900;
    let month = (unsafe { (*timeptr).tm_mon } + 1).cast_unsigned();
    let day = unsafe { (*timeptr).tm_mday }.cast_unsigned();
    let hour = unsafe { (*timeptr).tm_hour }.cast_unsigned();
    let minute = unsafe { (*timeptr).tm_min }.cast_unsigned();
    let second = unsafe { (*timeptr).tm_sec }.cast_unsigned();

    let Some(naive_local) = NaiveDate::from_ymd_opt(year, month, day)
        .and_then(|date| date.and_hms_opt(hour, minute, second))
    else {
        platform::ERRNO.set(EOVERFLOW);
        return -1;
    };

    match time_zone() {
        Some(tz) => {
            // IANA
            let isdst = unsafe { (*timeptr).tm_isdst };
            let tz_datetime = match tz.from_local_datetime(&naive_local) {
                MappedLocalTime::Single(datetime) => datetime,
                MappedLocalTime::Ambiguous(early, late) => {
                    if isdst > 0 {
                        early
                    } else {
                        late
                    }
                }
                MappedLocalTime::None => {
                    platform::ERRNO.set(EOVERFLOW);
                    return -1;
                }
            };
            let timestamp = tz_datetime.timestamp();

            unsafe { ptr::write(timeptr, datetime_to_tm(&tz_datetime)) };

            // Convert UTC time to local time
            let (std_time, dst_time) = match tz.timestamp_opt(timestamp, 0) {
                MappedLocalTime::Single(t) => (t, None),
                // This variant contains the two possible results, in the order (earliest, latest).
                MappedLocalTime::Ambiguous(t1, t2) => (t2, Some(t1)),
                MappedLocalTime::None => return timestamp,
            };
            {
                unsafe { set_timezone(&mut lock, &std_time, dst_time) };
            }

            timestamp
        }
        None => {
            // POSIX
            // GOAL: Make a new TZ of UTC, get the timestamp, add/subtract the 'timezone'
            let utc_datetime = naive_local.and_utc();
            let timestamp = utc_datetime.timestamp();

            let tz_posix = get_current_time_zone();
            let tz = PosixTz::parse(tz_posix);

            unsafe {
                set_timezone_posix(&mut lock, &tz);
            }
            #[cfg(target_pointer_width = "64")]
            let offset = unsafe { timezone };
            #[cfg(target_pointer_width = "32")]
            let offset = unsafe { i64::from(timezone) };
            timestamp + offset
        }
    }
}

// FIXME seems redox-rt sys posix_nanosleep calls wrapper which disables signals
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/nanosleep.html>.
///
/// Causes the current thread to be suspended from execution until either the
/// time interval specified by `rqtp` has elapsed or a signal is delivered to
/// the calling thread, and its action is to invoke a signal-catching function
/// or to terminate the process.
///
/// Has no effect on the action or blockage of any signal.
///
/// Upon success, returns `0`. Upon failure, returns `-1` and sets errno to
/// indicate the error. If `rmtp` is non-NULL and `nanosleep()` is interrupted
/// by a signal, returns `-1` and updates `rmtp` to contain the requested time
/// minus the actually elapsed time. If `rmtp` is NULL the remaining time is
/// not returned.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn nanosleep(rqtp: *const timespec, rmtp: *mut timespec) -> c_int {
    // copied() to avoid UB if rmtp == rqtp by reference
    let Some(rqtp) = (unsafe { rqtp.as_ref().cloned() }) else {
        return Err(Errno(EINVAL)).or_minus_one_errno();
    };
    Sys::nanosleep(&rqtp, unsafe { Out::nullable(rmtp) })
        .map(|()| 0)
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/strftime.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn strftime(
    s: *mut c_char,
    maxsize: size_t,
    format: *const c_char,
    timeptr: *const tm,
) -> size_t {
    let mut w = platform::StringWriter(s, maxsize);
    let ret = unsafe { strftime::strftime(&mut w, format, timeptr) };
    if ret < maxsize { ret } else { 0 }
}

// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/strftime.html>.
// TODO: needs locale_t
// #[unsafe(no_mangle)]
/*pub extern "C" fn strftime_l(s: *mut char, maxsize: size_t, format: *const c_char, timeptr: *const tm, locale: locale_t) -> size_t {
    unimplemented!();
}*/

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/time.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn time(tloc: *mut time_t) -> time_t {
    let mut ts = timespec::default();
    if Sys::clock_gettime(CLOCK_REALTIME, Out::from_mut(&mut ts)).is_ok() {}; // TODO what to do if Err?
    if !tloc.is_null() {
        unsafe { *tloc = ts.tv_sec }
    };
    ts.tv_sec
}

/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/timegm.3.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timegm(tm: *mut tm) -> time_t {
    let tm_val = unsafe { &mut *tm };
    let Some(dt) = convert_tm_generic(&Utc, tm_val) else {
        return -1;
    };

    unsafe {
        (*tm).tm_wday = c_int::try_from(dt.weekday().num_days_from_sunday()).expect("within range");
        (*tm).tm_yday = c_int::try_from(dt.ordinal0()).expect("within range"); // day of year starting at 0
        (*tm).tm_isdst = 0; // UTC does not use DST
        (*tm).tm_gmtoff = 0; // UTC offset is zero
        (*tm).tm_zone = UTC_STR.as_ptr().cast::<c_char>();
    }

    dt.timestamp()
}

/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/timegm.3.html>.
#[deprecated]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timelocal(tm: *mut tm) -> time_t {
    let tm_val = unsafe { &mut *tm };
    // POSIX TODO
    let tz = time_zone().unwrap_or(Tz::UTC);
    let Some(dt) = convert_tm_generic(&tz, tm_val) else {
        return -1;
    };

    let tz_name = CString::new(tz.name()).unwrap();
    #[cfg(target_pointer_width = "64")]
    let tm_gmtoff = dt.offset().fix().local_minus_utc().into();
    #[cfg(target_pointer_width = "32")]
    let tm_gmtoff = dt.offset().fix().local_minus_utc();
    unsafe {
        (*tm).tm_wday = c_int::try_from(dt.weekday().num_days_from_sunday()).expect("within range");
        (*tm).tm_yday = c_int::try_from(dt.ordinal0()).expect("within range"); // day of year starting at 0
        (*tm).tm_isdst =
            c_int::try_from(dt.offset().dst_offset().num_hours()).expect("within range");
        (*tm).tm_gmtoff = tm_gmtoff;
        (*tm).tm_zone = tz_name.into_raw().cast();
    }

    dt.timestamp()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timer_create.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timer_create(
    clock_id: clockid_t,
    evp: *mut sigevent,
    timerid: *mut timer_t,
) -> c_int {
    let (Some(evp), Some(mut timerid)) = (unsafe { (evp.as_ref(), Out::nullable(timerid)) }) else {
        return Err(Errno(EINVAL)).or_minus_one_errno();
    };
    Sys::timer_create(clock_id, evp)
        .map(|timer| {
            timerid.write(timer);
            0
        })
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timer_delete.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timer_delete(timerid: timer_t) -> c_int {
    Sys::timer_delete(timerid).map(|()| 0).or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timer_getoverrun.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn timer_getoverrun(timerid: timer_t) -> c_int {
    unimplemented!();
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timer_gettime.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timer_gettime(timerid: timer_t, value: *mut itimerspec) -> c_int {
    let Some(mut value) = (unsafe { Out::nullable(value) }) else {
        return Err(Errno(EINVAL)).or_minus_one_errno();
    };
    Sys::timer_gettime(timerid)
        .map(|itimer| {
            value.write(itimer);
            0
        })
        .or_minus_one_errno()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timer_settime.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timer_settime(
    timerid: timer_t,
    flags: c_int,
    value: *const itimerspec,
    ovalue: *mut itimerspec,
) -> c_int {
    let (Some(value), ovalue) = (unsafe { (value.as_ref(), Out::nullable(ovalue)) }) else {
        return Err(Errno(EINVAL)).or_minus_one_errno();
    };
    Sys::timer_settime(timerid, flags, value, ovalue)
        .map(|()| 0)
        .or_minus_one_errno()
}

/// ISO C equivalent to [`Sys::clock_gettime`].
///
/// The main differences are that this function:
/// * returns `0` on error and `base` on success
/// * only mandates TIME_UTC as a base
///
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/timespec_get.html>.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timespec_get(tp: *mut timespec, base: c_int) -> c_int {
    let tp = unsafe { Out::nonnull(tp) };
    Sys::clock_gettime(base - 1, tp).map(|()| base).unwrap_or(0)
}

/// ISO C equivalent to [`Sys::clock_getres`].
///
/// The main differences are that this function:
/// * returns `0` on error and `base` on success
/// * only mandates TIME_UTC as a base
#[unsafe(no_mangle)]
pub unsafe extern "C" fn timespec_getres(res: *mut timespec, base: c_int) -> c_int {
    let res = unsafe { Out::nullable(res) };
    Sys::clock_getres(base - 1, res).map(|()| base).unwrap_or(0)
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/tzset.html>.
///
/// # Safety
/// The caller must ensure that [`daylight`], [`timezone`] and [`tzname`] are
/// not accessed by user code for the duration of the call.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn tzset() {
    let mut lock = TIMEZONE_LOCK.lock();
    // SAFETY: the caller is required to ensure that `daylight`, `timezone`
    // and `tzname` are not accessed by user code.
    unsafe { clear_timezone(&mut lock) };

    let tz_option = time_zone();

    match tz_option {
        Some(tz) => {
            // IANA
            let datetime = now();
            let (std_time, dst_time) = match tz.from_local_datetime(&datetime) {
                MappedLocalTime::Single(t) => (t, None),
                // This variant contains the two possible results, in the order (earliest, latest).
                MappedLocalTime::Ambiguous(t1, t2) => (t2, Some(t1)),
                MappedLocalTime::None => return,
            };

            // SAFETY: the caller is required to ensure that `daylight`, `timezone`
            // and `tzname` are not accessed by user code.
            unsafe { set_timezone(&mut lock, &std_time, dst_time) }
        }
        None => {
            // POSIX
            let tz_posix = get_current_time_zone();
            let tz = PosixTz::parse(tz_posix);
            unsafe {
                set_timezone_posix(&mut lock, &tz);
            }
        }
    }
}

fn convert_tm_generic<Tz: TimeZone>(tz: &Tz, tm_val: &tm) -> Option<DateTime<Tz>> {
    // Adjust fields: tm_year is years since 1900; tm_mon is 0-indexed.
    let year = tm_val.tm_year + 1900;
    let month = tm_val.tm_mon + 1; // convert to 1-indexed
    let day = tm_val.tm_mday;
    let hour = tm_val.tm_hour;
    let minute = tm_val.tm_min;
    let second = tm_val.tm_sec;

    match tz.with_ymd_and_hms(
        year,
        month.cast_unsigned(),
        day.cast_unsigned(),
        hour.cast_unsigned(),
        minute.cast_unsigned(),
        second.cast_unsigned(),
    ) {
        MappedLocalTime::Single(dt) => Some(dt),
        MappedLocalTime::Ambiguous(dt1, _dt2) => Some(dt1), // choose the earliest value
        _ => None,
    }
}

/// # Safety
/// The caller must ensure that `daylight`, `timezone` and `tzname` are not
/// accessed by user code for the duration of the call (relibc functions are
/// required to hold `TIMEZONE_LOCK` when accessing these).
unsafe fn clear_timezone(guard: &mut MutexGuard<'_, (Option<CString>, Option<CString>)>) {
    guard.0 = None;
    guard.1 = None;

    // SAFETY: the caller is required to ensure access exclusively for the
    // holder of `TIMEZONE_LOCK`.
    unsafe {
        tzname.0[0] = ptr::null_mut();
        tzname.0[1] = ptr::null_mut();
        timezone = 0;
        daylight = 0;
    }
}

#[inline(always)]
fn get_system_time_zone<'a>() -> Option<&'a str> {
    // Resolve the symlink for localtime
    const BSIZE: size_t = 100;
    let mut buffer: [u8; BSIZE] = [0; BSIZE];

    #[cfg(not(target_os = "redox"))]
    let (localtime, prefix) = (c"/etc/localtime", "/usr/share/zoneinfo/");

    #[cfg(target_os = "redox")]
    let (localtime, prefix) = (c"/etc/localtime", "/usr/share/zoneinfo/");

    if unsafe { readlink(localtime.as_ptr().cast(), buffer.as_mut_ptr().cast(), BSIZE) } == -1 {
        return None;
    }

    let path = unsafe { CStr::from_ptr(buffer.as_mut_ptr().cast()) };

    if let Ok(tz_name) = path.to_str()
        && let Some(stripped) = tz_name.strip_prefix(prefix)
    {
        return Some(stripped);
    }

    None
}

fn get_current_time_zone<'a>() -> &'a str {
    // Check the `TZ` environment variable
    if let Some(tz) = stdlib::getenv_str(c"TZ") {
        return tz;
    }

    // Fallback to the system's default time zone
    if let Some(tz) = get_system_time_zone() {
        return tz;
    }

    // If all else fails, use UTC
    "UTC"
}

#[inline(always)]
fn time_zone() -> Option<Tz> {
    get_current_time_zone().parse().ok() //.unwrap_or(Tz::UTC)
}

#[inline(always)]
fn now() -> NaiveDateTime {
    let mut now = timespec::default();
    if Sys::clock_gettime(CLOCK_REALTIME, Out::from_mut(&mut now)).is_ok() {}; // TODO what to do if Err?
    DateTime::from_timestamp(now.tv_sec, u32::try_from(now.tv_nsec).unwrap_or(u32::MAX))
        .unwrap_or_default()
        .naive_local()
}

#[inline(always)]
fn get_localtime(
    timer: time_t,
    mut result: Out<tm>,
) -> (Option<DateTime<Tz>>, Option<DateTime<Tz>>) {
    // POSIX TODO
    let tz = time_zone().unwrap_or(Tz::UTC);

    // Convert UTC time to local time
    let (std_time, dst_time) = match tz.timestamp_opt(timer, 0) {
        MappedLocalTime::Single(t) => (Some(t), None),
        // This variant contains the two possible results, in the order (earliest, latest).
        MappedLocalTime::Ambiguous(t1, t2) => (Some(t2), Some(t1)),
        MappedLocalTime::None => return (None, None),
    };

    let localtime = datetime_to_tm(&std_time.unwrap());
    result.write(localtime);
    (std_time, dst_time)
}

fn datetime_to_tm(local_time: &DateTime<Tz>) -> tm {
    let tz = local_time.timezone().name();
    let tz = tz.strip_prefix("Etc/").unwrap_or(tz);

    let mut t = blank_tm();
    // Populate the `tm` structure
    t.tm_sec = c_int::try_from(local_time.second()).expect("within range");
    t.tm_min = c_int::try_from(local_time.minute()).expect("within range");
    t.tm_hour = c_int::try_from(local_time.hour()).expect("within range");
    t.tm_mday = c_int::try_from(local_time.day()).expect("within range");
    t.tm_mon = c_int::try_from(local_time.month0()).expect("within range"); // 0-based month
    t.tm_year = (local_time.year() - 1900) as _; // Years since 1900
    t.tm_wday = c_int::try_from(local_time.weekday().num_days_from_sunday()).expect("within range");
    t.tm_yday = c_int::try_from(local_time.ordinal0()).expect("within range"); // 0-based day of year

    let offset = local_time.offset();
    t.tm_isdst = c_int::try_from(offset.dst_offset().num_hours()).expect("within range");
    // Get the UTC offset in seconds
    #[cfg(target_pointer_width = "64")]
    let tm_gtoff = offset.fix().local_minus_utc().into();
    #[cfg(target_pointer_width = "32")]
    let tm_gtoff = offset.fix().local_minus_utc();
    t.tm_gmtoff = tm_gtoff;

    let tm_zone = {
        let mut timezone_names = TIMEZONE_NAMES.lock();
        timezone_names.get_or_init(BTreeSet::new);
        let cstr = CString::new(tz).expect("shouldn't contain null bytes");
        timezone_names
            .get_mut()
            .expect("already initialised")
            .insert(cstr.clone());
        timezone_names
            .get()
            .expect("already initialised")
            .get(&cstr)
            .expect("inserted above")
            .as_ptr()
    };

    t.tm_zone = tm_zone.cast();
    t
}

/// # Safety
/// The caller must ensure that `daylight`, `timezone` and `tzname` are not
/// accessed by user code for the duration of the call (relibc functions are
/// required to hold `TIMEZONE_LOCK` when accessing these).
unsafe fn set_timezone(
    guard: &mut MutexGuard<'_, (Option<CString>, Option<CString>)>,
    std: &DateTime<Tz>,
    dst: Option<DateTime<Tz>>,
) {
    // SAFETY: the caller is required to ensure access exclusively for the
    // holder of `TIMEZONE_LOCK`.
    unsafe {
        let ut_offset = std.offset();

        guard.0 = Some(CString::new(ut_offset.abbreviation().expect("Wrong timezone")).unwrap());
        tzname.0[0] = guard.0.as_ref().unwrap().as_ptr().cast_mut();

        match dst {
            Some(dst) => {
                guard.1 = Some(
                    CString::new(dst.offset().abbreviation().expect("Wrong timezone")).unwrap(),
                );
                tzname.0[1] = guard.1.as_ref().unwrap().as_ptr().cast_mut();
                daylight = 1;
            }
            None => {
                guard.1 = None;
                tzname.0[1] = guard.0.as_ref().unwrap().as_ptr().cast_mut();
                daylight = 0;
            }
        }

        timezone = -c_long::from(ut_offset.fix().local_minus_utc());
    }
}

/// # Safety
/// The caller must ensure that `daylight`, `timezone` and `tzname` are not
/// accessed by user code for the duration of the call (relibc functions are
/// required to hold `TIMEZONE_LOCK` when accessing these).
unsafe fn set_timezone_posix(
    guard: &mut MutexGuard<'_, (Option<CString>, Option<CString>)>,
    tz: &PosixTz<'_>,
) {
    // SAFETY: the caller is required to ensure access exclusively for the
    // holder of `TIMEZONE_LOCK`.
    unsafe {
        guard.0 = Some(CString::new(tz.std).unwrap());
        guard.1 = Some(CString::new(tz.dst).unwrap());

        tzname.0[0] = guard.0.as_ref().unwrap().as_ptr().cast_mut();
        tzname.0[1] = guard.1.as_ref().unwrap().as_ptr().cast_mut();
        daylight = i32::from(tz.daylight);
        timezone = tz.timezone.unwrap_or(0);
    }
}

const fn blank_tm() -> tm {
    tm {
        tm_year: 0,
        tm_mon: 0,
        tm_mday: 0,
        tm_hour: 0,
        tm_min: 0,
        tm_sec: 0,
        tm_wday: 0,
        tm_yday: 0,
        tm_isdst: -1,
        tm_gmtoff: 0,
        tm_zone: ptr::null_mut(),
    }
}

pub(crate) fn timespec_realtime_to_monotonic(abstime: &timespec) -> Result<timespec, Errno> {
    let mut realtime = timespec::default();
    unsafe { clock_gettime(CLOCK_REALTIME, &raw mut realtime) };
    let mut monotonic = timespec::default();
    unsafe { clock_gettime(CLOCK_MONOTONIC, &raw mut monotonic) };
    let Some(delta) = timespec::subtract(abstime, &realtime) else {
        return Err(Errno(ETIMEDOUT));
    };
    let Some(relative) = timespec::add(&monotonic, &delta) else {
        return Err(Errno(ENOMEM));
    };
    Ok(relative)
}
