//! POSIX header implementations.

pub mod _aio;
pub mod _fenv;
pub mod arpa_inet;
pub mod assert;
pub mod bits_arpainet;
#[path = "bits_clock-t/mod.rs"]
pub mod bits_clock_t;
#[path = "bits_clockid-t/mod.rs"]
pub mod bits_clockid_t;
#[path = "bits_dev-t/mod.rs"]
pub mod bits_dev_t;
pub mod bits_fcntl;
#[path = "bits_gid-t/mod.rs"]
pub mod bits_gid_t;
#[path = "bits_id-t/mod.rs"]
pub mod bits_id_t;
#[path = "bits_ino-t/mod.rs"]
pub mod bits_ino_t;
#[path = "bits_intptr-t/mod.rs"]
pub mod bits_intptr_t;
pub mod bits_iovec;
#[path = "bits_key-t/mod.rs"]
pub mod bits_key_t;
pub mod bits_limits_ptdi;
#[path = "bits_locale-t/mod.rs"]
pub mod bits_locale_t;
#[path = "bits_mode-t/mod.rs"]
pub mod bits_mode_t;
#[path = "bits_nlink-t/mod.rs"]
pub mod bits_nlink_t;
pub mod bits_null;
#[path = "bits_off-t/mod.rs"]
pub mod bits_off_t;
#[path = "bits_open-flags/mod.rs"]
pub mod bits_open_flags;
#[path = "bits_pid-t/mod.rs"]
pub mod bits_pid_t;
pub mod bits_pthread;
#[path = "bits_pthread-t/mod.rs"]
pub mod bits_pthread_t;
#[path = "bits_pthreadattr-t/mod.rs"]
pub mod bits_pthreadattr_t;
pub mod bits_pthreadoi;
#[path = "bits_pthreadonce-t/mod.rs"]
pub mod bits_pthreadonce_t;
#[path = "bits_reclen-t/mod.rs"]
pub mod bits_reclen_t;
#[path = "bits_safamily-t/mod.rs"]
pub mod bits_safamily_t;
#[path = "bits_sigset-t/mod.rs"]
pub mod bits_sigset_t;
#[path = "bits_size-t/mod.rs"]
pub mod bits_size_t;
#[path = "bits_socklen-t/mod.rs"]
pub mod bits_socklen_t;
#[path = "bits_ssize-t/mod.rs"]
pub mod bits_ssize_t;
#[path = "bits_suseconds-t/mod.rs"]
pub mod bits_suseconds_t;
pub mod bits_sys_stat;
pub mod bits_sys_statvfs;
pub mod bits_threads;
#[path = "bits_time-t/mod.rs"]
pub mod bits_time_t;
#[path = "bits_timer-t/mod.rs"]
pub mod bits_timer_t;
pub mod bits_timespec;
pub mod bits_timeval;
pub mod bits_ucred;
#[path = "bits_uid-t/mod.rs"]
pub mod bits_uid_t;
#[path = "bits_uint32-t/mod.rs"]
pub mod bits_uint32_t;
pub mod bits_uio;
#[path = "bits_useconds-t/mod.rs"]
pub mod bits_useconds_t;
pub mod bits_valist;
#[path = "bits_wchar-t/mod.rs"]
pub mod bits_wchar_t;
pub mod bits_winsize;
// complex.h implemented in C (currently through openlibm)
pub mod cpio;
pub mod crypt;
pub mod ctype;
// TODO: curses.h (deprecated)
// TODO: devctl.h
pub mod dirent;
#[path = "dl-tls/mod.rs"]
pub mod dl_tls;
pub mod dlfcn;
pub mod elf;
pub mod endian;
pub mod err;
pub mod errno;
pub mod fcntl;
pub mod float;
pub mod fmtmsg;
pub mod fnmatch;
// TODO: ftw.h
pub mod getopt;
pub mod glob;
pub mod grp;
// TODO: iconv.h
pub mod ifaddrs;
pub mod inttypes;
// iso646.h implemented in C
pub mod langinfo;
// TODO: libintl.h
pub mod libgen;
pub mod limits;
pub mod link;
pub mod locale;
pub mod malloc;
// TODO unfinished, unguard feature when ready
#[cfg(feature = "math_libm")]
pub mod math;
pub mod monetary;
// TODO: mqueue.h
// TODO: ndbm.h
pub mod net_if;
pub mod netdb;
pub mod netinet_in;
pub mod netinet_ip;
pub mod netinet_tcp;
// TODO: nl_types.h
// TODO: Remove C header paths.h when cbindgen can export C/Rust strs
// pub mod paths;
pub mod poll;
pub mod pthread;
pub mod pty;
pub mod pwd;
// TODO: re_comp.h (deprecated)
pub mod regex;
// TODO: regexp.h (deprecated)
pub mod sched;
// TODO: search.h
pub mod semaphore;
pub mod setjmp;
pub mod sgtty;
pub mod shadow;
pub mod signal;
pub mod spawn;
// TODO: stdalign.h (likely C implementation)
pub mod stdarg;
// stdatomic.h implemented in C
// stdbool.h implemented in C
pub mod stddef;
// stdint.h implemented in C
pub mod stdio;
pub mod stdlib;
// TODO: stdnoreturn.h (likely C implementation)
pub mod string;
pub mod strings;
// TODO: stropts.h (deprecated)
pub mod sys_auxv;
pub mod sys_epoll;
pub mod sys_file;
pub mod sys_ioctl;
pub mod sys_ipc;
pub mod sys_mman;
// TODO: sys/msg.h
pub mod sys_ptrace;
pub mod sys_resource;
pub mod sys_select;
// TODO: sys/sem.h
pub mod sys_shm;
pub mod sys_socket;
pub mod sys_stat;
pub mod sys_statvfs;
pub mod sys_syscall;
pub mod sys_time;
#[deprecated]
pub mod sys_timeb;
//pub mod sys_times;
pub mod arch_aarch64_user;
pub mod arch_riscv64_user;
pub mod arch_x64_user;
#[cfg(not(target_arch = "x86"))] // TODO: x86
pub mod sys_procfs;
pub mod sys_random;
pub mod sys_syslog;
pub mod sys_types;
pub mod sys_types_extra;
pub mod sys_uio;
pub mod sys_un;
pub mod sys_utsname;
pub mod sys_wait;
pub mod sysexits;
pub mod tar;
// TODO: term.h (deprecated)
pub mod termios;
// TODO: tgmath.h (likely C implementation currenly through openlibm)
pub mod threads;
pub mod time;
// TODO: uchar.h
// TODO: ucontext.h (deprecated)
// TODO: ulimit.h (deprecated)
// TODO: unctrl.h (deprecated)
pub mod unistd;
#[deprecated]
pub mod utime;
pub mod utmp;
// TODO: utmpx.h
// TODO: varargs.h (deprecated)
pub mod wchar;
pub mod wctype;
// TODO: wordexp.h
// TODO: xti.h (deprecated)
#[cfg(target_os = "redox")]
pub mod redox_ring;
