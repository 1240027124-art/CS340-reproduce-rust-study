//! `limits.h` implementation.
//!
//! See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/limits.h.html>.

use crate::platform::types::{
    c_char, c_int, c_long, c_longlong, c_schar, c_short, c_uchar, c_uint, c_ulonglong, c_ushort,
};

pub use crate::header::bits_limits_ptdi::{
    _POSIX_THREAD_DESTRUCTOR_ITERATIONS, PTHREAD_DESTRUCTOR_ITERATIONS,
};

/// Maximum number of bytes in a filename (not including the terminating null
/// of a filename string).
pub const NAME_MAX: usize = 255;
pub const PASS_MAX: usize = 128;
/// Maximum number of bytes the implementation stores as a pathname in a
/// user-supplied buffer of unspecified size, including the terminating null
/// character.
pub const PATH_MAX: usize = 4096;
/// Maximum number of simultaneous supplementary group IDs per process.
pub const NGROUPS_MAX: usize = 65536;
/// Maximum number of `iovec` structures that one process has available for
/// use with `readv()` or `writev()`.
pub const IOV_MAX: c_int = 1024;

/// Minimum required value for `IOV_MAX`.
pub const _XOPEN_IOV_MAX: c_int = 16;
/// Minimum required value for `NAME_MAX`.
pub const _XOPEN_NAME_MAX: c_long = 255;
/// Minimum required value for `PATH_MAX`.
pub const _XOPEN_PATH_MAX: c_long = 1024;

pub const CHAR_BIT: u32 = 8;
pub const WORD_BIT: u32 = 32;
#[cfg(target_pointer_width = "32")]
pub const LONG_BIT: u32 = 32;
#[cfg(target_pointer_width = "64")]
pub const LONG_BIT: u32 = 64;

#[cfg(any(target_arch = "aarch64", target_arch = "riscv64"))]
pub const CHAR_MAX: c_char = 0xFF;
#[cfg(not(any(target_arch = "aarch64", target_arch = "riscv64")))]
pub const CHAR_MAX: c_char = 0x7F;
pub const SCHAR_MAX: c_schar = 0x7F;
pub const SHRT_MAX: c_short = 0x7FFF;
pub const INT_MAX: c_int = 0x7FFF_FFFF;
// suffixes for adding 'u', 'll', 'ull'. TODO: no suffix or 'ul' and 'l'.
// https://github.com/mozilla/cbindgen/blob/d3bf7d6/src/bindgen/ir/constant.rs#L530
// LONG_MAX is defined in cbindgen.toml
pub const LLONG_MAX: c_longlong = 0x7FFF_FFFF_FFFF_FFFF_i64;
pub const UCHAR_MAX: c_uchar = 0xFF;
pub const USHRT_MAX: c_ushort = 0xFFFF;
pub const UINT_MAX: c_uint = 0xFFFFFFFF_u32;
// SSIZE_MAX is defined in cbindgen.toml
// ULONG_MAX is defined in cbindgen.toml
pub const ULLONG_MAX: c_ulonglong = 0xFFFF_FFFF_FFFF_FFFF_u64;

#[cfg(any(target_arch = "aarch64", target_arch = "riscv64"))]
pub const CHAR_MIN: c_char = 0;
#[cfg(not(any(target_arch = "aarch64", target_arch = "riscv64")))]
pub const CHAR_MIN: c_char = -0x80;
pub const SCHAR_MIN: c_schar = -SCHAR_MAX - 1;
pub const SHRT_MIN: c_short = -SHRT_MAX - 1;
pub const INT_MIN: c_int = -INT_MAX - 1;
// LONG_MIN is defined in cbindgen.toml
pub const LLONG_MIN: c_longlong = -LLONG_MAX - 1;

/// Maximum number of bytes in a character, for any supported locale.
pub const MB_LEN_MAX: c_int = 4;

// TODO: 4096 for most architectures as determined by a quick grep of musl's source; need a better
// way to determine it for other archs or to hard code a value.
#[cfg(target_os = "linux")]
pub const PAGE_SIZE: usize = 4096;

// These POSIX symbols must have these values regardless of OS
pub const _POSIX_AIO_LISTIO_MAX: c_long = 2;
pub const _POSIX_AIO_MAX: c_long = 1;
pub const _POSIX_ARG_MAX: c_long = 4096;
pub const _POSIX_CHILD_MAX: c_long = 25;
pub const _POSIX_CLOCKRES_MIN: c_long = 20000000;
pub const _POSIX_DELAYTIMER_MAX: c_long = 32;
pub const _POSIX_HOST_NAME_MAX: c_long = 255;
/// Minimum required value for `LINK_MAX`.
pub const _POSIX_LINK_MAX: c_long = 8;
pub const _POSIX_LOGIN_NAME_MAX: c_long = 9;
/// Minimum required value for `MAX_CANON`.
pub const _POSIX_MAX_CANON: c_long = 255;
/// Minimum required value for `MAX_INPUT`.
pub const _POSIX_MAX_INPUT: c_long = 255;
/// Minimum required value for `NAME_MAX`.
pub const _POSIX_NAME_MAX: c_long = 14;
pub const _POSIX_NGROUPS_MAX: c_long = 8;
pub const _POSIX_OPEN_MAX: c_long = 20;
/// Minimum required value for `PATH_MAX`.
pub const _POSIX_PATH_MAX: c_long = 256;
/// Minimum required value for `PIPE_BUF`.
pub const _POSIX_PIPE_BUF: c_long = 512;
pub const _POSIX_RE_DUP_MAX: c_long = 255;
pub const _POSIX_RTSIG_MAX: c_long = 8;
pub const _POSIX_SEM_NSEMS_MAX: c_long = 256;
pub const _POSIX_SEM_VALUE_MAX: c_long = 32767;
pub const _POSIX_SIGQUEUE_MAX: c_long = 32;
pub const _POSIX_SSIZE_MAX: c_long = 32767;
pub const _POSIX_STREAM_MAX: c_long = 8;
/// Minimum required value for `SYMLINK_MAX`.
pub const _POSIX_SYMLINK_MAX: c_long = 255;
/// Minimum required value for `SYMLOOP_MAX`.
pub const _POSIX_SYMLOOP_MAX: c_long = 8;
// _POSIX_THREAD_DESTRUCTOR_ITERATIONS defined in bits file
pub const _POSIX_THREAD_KEYS_MAX: c_long = 128;
pub const _POSIX_THREAD_THREADS_MAX: c_long = 64;
pub const _POSIX_TIMER_MAX: c_long = 32;
pub const _POSIX_TTY_NAME_MAX: c_long = 9;
pub const _POSIX_TZNAME_MAX: c_long = 6;

pub const _POSIX2_BC_BASE_MAX: c_long = 99;
pub const _POSIX2_BC_DIM_MAX: c_long = 2048;
pub const _POSIX2_BC_SCALE_MAX: c_long = 99;
pub const _POSIX2_BC_STRING_MAX: c_long = 1000;
pub const _POSIX2_CHARCLASS_NAME_MAX: c_long = 14;
pub const _POSIX2_COLL_WEIGHTS_MAX: c_long = 2;
pub const _POSIX2_EXPR_NEST_MAX: c_long = 32;
pub const _POSIX2_LINE_MAX: c_long = 2048;
pub const _POSIX2_RE_DUP_MAX: c_long = 255;

// These symbols must be at least the POSIX values, and sysconf will return the actual value between
// the posix minimum and this maximum.
pub const BC_BASE_MAX: c_long = _POSIX2_BC_BASE_MAX;
pub const BC_DIM_MAX: c_long = _POSIX2_BC_DIM_MAX;
pub const BC_SCALE_MAX: c_long = _POSIX2_BC_SCALE_MAX;
pub const BC_STRING_MAX: c_long = _POSIX2_BC_STRING_MAX;
pub const CHARCLASS_NAME_MAX: c_long = _POSIX2_CHARCLASS_NAME_MAX;
pub const COLL_WEIGHTS_MAX: c_long = _POSIX2_COLL_WEIGHTS_MAX;
pub const EXPR_NEST_MAX: c_long = _POSIX2_EXPR_NEST_MAX;
pub const LINE_MAX: c_long = _POSIX2_LINE_MAX;
pub const RE_DUP_MAX: c_long = _POSIX2_RE_DUP_MAX;
pub const HOST_NAME_MAX: c_long = _POSIX_HOST_NAME_MAX;
pub const LOGIN_NAME_MAX: c_long = 255;
pub const GETENTROPY_MAX: c_long = 256;
/// Maximum number of links to a single file.
pub const LINK_MAX: c_long = 127;
/// Maximum number of bytes that is guaranteed to be atomic when writing to a
/// pipe.
pub const PIPE_BUF: c_long = 4096;
/// Minimum number of bits needed to represent, as a signed integer value, the
/// maximum size of a regular file allowed in the specified directory.
pub const FILESIZEBITS: c_long = 64;
/// Maximum number of bytes in a terminal canonical input line.
pub const MAX_CANON: c_long = _POSIX_MAX_CANON;
/// Maximum number of bytes for which space is available in a terminal input
/// queue; therefore, the maximum number of bytes a conforming application may
/// require to be typed as input before reading them.
pub const MAX_INPUT: c_long = _POSIX_MAX_INPUT;
/// Maximum number of bytes in a symbolic link.
pub const SYMLINK_MAX: c_long = _POSIX_SYMLINK_MAX;
/// Minimum number of bytes of storage actually allocated for any portion of a
/// file.
pub const POSIX_ALLOC_SIZE_MIN: c_long = 4096;

// PTHREAD_DESTRUCTOR_ITERATIONS defined in bits file
// TODO: What should this limit be? Both glibc and musl have it as 1024
pub const PTHREAD_KEYS_MAX: c_long = 4096 * 32;
pub const PTHREAD_STACK_MIN: c_long = 65536;
/// Maximum number of symbolic links that can be reliably traversed in the
/// resolution of a pathname in the absence of a loop.
pub const SYMLOOP_MAX: c_long = 64;
/// Maximum length of terminal device name.
pub const TTY_NAME_MAX: c_long = 32; // "/scheme/pty/".len() + size of usize::MAX as string + 1
