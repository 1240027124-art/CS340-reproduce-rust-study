//! `sched.h` implementation.
//!
//! See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/sched.h.html>.

use crate::{
    error::ResultExt,
    header::time::timespec,
    platform::{
        Pal, Sys,
        types::{c_int, pid_t},
    },
};

// TODO: There are extensions, but adding more member is breaking ABI for pthread_attr_t
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/sched.h.html>.
///
/// Scheduling parameters required for each supported scheduling policy.
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct sched_param {
    /// Process or thread execution scheduling priority.
    pub sched_priority: c_int,
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/sched.h.html>.
///
/// First in first out (FIFO) scheduling policy.
pub const SCHED_FIFO: c_int = 0;
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/sched.h.html>.
///
/// Round robin scheduling policy.
pub const SCHED_RR: c_int = 1;
/// See <https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/sched.h.html>.
///
/// Another scheduling policy.
pub const SCHED_OTHER: c_int = 2;

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_get_priority_max.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn sched_get_priority_max(policy: c_int) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_get_priority_max.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn sched_get_priority_min(policy: c_int) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_getparam.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub unsafe extern "C" fn sched_getparam(pid: pid_t, param: *mut sched_param) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_rr_get_interval.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn sched_rr_get_interval(pid: pid_t, time: *const timespec) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_setparam.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub unsafe extern "C" fn sched_setparam(pid: pid_t, param: *const sched_param) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_setscheduler.html>.
// #[unsafe(no_mangle)]
#[expect(unused_variables, reason = "function not yet implemented")]
pub extern "C" fn sched_setscheduler(
    pid: pid_t,
    policy: c_int,
    param: *const sched_param,
) -> c_int {
    todo!()
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/sched_yield.html>.
///
/// Force the running thread to relinquish the processor until it again
/// becomes the head of its thread list.
#[unsafe(no_mangle)]
pub extern "C" fn sched_yield() -> c_int {
    Sys::sched_yield().map(|()| 0).or_minus_one_errno()
}
