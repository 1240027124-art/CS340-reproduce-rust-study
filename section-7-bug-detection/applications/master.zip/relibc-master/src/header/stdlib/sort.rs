use crate::platform::types::{c_char, c_int, c_void, size_t};

pub trait SortContext {
    fn compare(&mut self, a: *const c_void, b: *const c_void) -> c_int;
}

pub struct QsortContext {
    pub comp: extern "C" fn(*const c_void, *const c_void) -> c_int,
}
impl SortContext for QsortContext {
    #[inline]
    fn compare(&mut self, a: *const c_void, b: *const c_void) -> c_int {
        (self.comp)(a, b)
    }
}

pub struct QsortRContext {
    pub comp: extern "C" fn(*const c_void, *const c_void, *mut c_void) -> c_int,
    pub arg: *mut c_void,
}
impl SortContext for QsortRContext {
    #[inline]
    fn compare(&mut self, a: *const c_void, b: *const c_void) -> c_int {
        (self.comp)(a, b, self.arg)
    }
}

pub unsafe fn introsort<C: SortContext>(
    base: *mut c_char,
    nel: size_t,
    width: size_t,
    comp: &mut C,
) {
    /*TODO: introsort is much faster than insertion sort, but is currently broken
    let maxdepth = 2 * log2(nel);
    introsort_helper(base, nel, width, maxdepth, comp);
    */
    unsafe { insertion_sort(base, nel, width, comp) };
}

// NOTE: if num is 0, the result should be considered undefined
fn log2(num: size_t) -> size_t {
    // TODO use try_from instead of as casts when const stable
    const IS_32_BIT: bool = size_t::MAX as u32 as size_t == size_t::MAX;

    let max_bits = if IS_32_BIT {
        31
    } else {
        // assuming we are 64-bit (this may or may not need to be updated in the future)
        63
    };

    max_bits - num.to_le().leading_zeros() as size_t
}

unsafe fn introsort_helper<C: SortContext>(
    mut base: *mut c_char,
    mut nel: size_t,
    width: size_t,
    mut maxdepth: size_t,
    comp: &mut C,
) {
    const THRESHOLD: size_t = 8;

    // this loop is a trick to save stack space because TCO is not a thing in Rustland
    // basically, we just change the arguments and loop rather than recursing for the second call
    // to introsort_helper()
    loop {
        if nel < THRESHOLD {
            unsafe { insertion_sort(base, nel, width, comp) };
            break;
        } else if nel > 1 {
            if maxdepth == 0 {
                unsafe { heapsort(base, nel, width, comp) };
                break;
            } else {
                let (left, right) = unsafe { partition(base, nel, width, comp) };
                let right_base = unsafe { base.add((right + 1) * width) };
                let right_nel = nel - (right + 1);
                maxdepth -= 1;
                if left < nel - right {
                    unsafe { introsort_helper(base, left, width, maxdepth, comp) };
                    base = right_base;
                    nel = right_nel;
                } else {
                    unsafe { introsort_helper(right_base, right_nel, width, maxdepth, comp) };
                    nel = left;
                }
            }
        }
    }
}

unsafe fn insertion_sort<C: SortContext>(
    base: *mut c_char,
    nel: size_t,
    width: size_t,
    comp: &mut C,
) {
    for i in 0..nel {
        for j in (0..i).rev() {
            let current = unsafe { base.add(j * width) };
            let prev = unsafe { base.add((j + 1) * width) };
            if comp.compare(current as *const c_void, prev as *const c_void) > 0 {
                unsafe { swap(current, prev, width) };
            } else {
                break;
            }
        }
    }
}

unsafe fn heapsort<C: SortContext>(base: *mut c_char, nel: size_t, width: size_t, comp: &mut C) {
    unsafe { heapify(base, nel, width, comp) };

    let mut end = nel - 1;
    while end > 0 {
        let end_ptr = unsafe { base.add(end * width) };
        unsafe { swap(end_ptr, base, width) };
        end -= 1;
        unsafe { heap_sift_down(base, 0, end, width, comp) };
    }
}

unsafe fn heapify<C: SortContext>(base: *mut c_char, nel: size_t, width: size_t, comp: &mut C) {
    // we start at the last parent in the heap (the parent of the last child)
    let last_parent = (nel - 2) / 2;

    for start in (0..=last_parent).rev() {
        unsafe { heap_sift_down(base, start, nel - 1, width, comp) };
    }
}

unsafe fn heap_sift_down<C: SortContext>(
    base: *mut c_char,
    start: size_t,
    end: size_t,
    width: size_t,
    comp: &mut C,
) {
    // get the left child of the node at the given index
    let left_child = |idx| 2 * idx + 1;

    let mut root = start;

    while left_child(root) <= end {
        let child = left_child(root);
        let mut swap_idx = root;

        let root_ptr = unsafe { base.add(root * width) };
        let mut swap_ptr = unsafe { base.add(swap_idx * width) };
        let first_child_ptr = unsafe { base.add(child * width) };
        let second_child_ptr = unsafe { base.add((child + 1) * width) };

        if comp.compare(swap_ptr as *const c_void, first_child_ptr as *const c_void) < 0 {
            swap_idx = child;
            swap_ptr = first_child_ptr;
        }
        if child < end
            && comp.compare(swap_ptr as *const c_void, second_child_ptr as *const c_void) < 0
        {
            swap_idx = child + 1;
            swap_ptr = second_child_ptr;
        }

        if swap_idx == root {
            break;
        } else {
            unsafe { swap(root_ptr, swap_ptr, width) };
            root = swap_idx;
        }
    }
}

#[inline]
unsafe fn partition<C: SortContext>(
    base: *mut c_char,
    nel: size_t,
    width: size_t,
    comp: &mut C,
) -> (size_t, size_t) {
    // calculate the median of the first, middle, and last elements and use it as the pivot
    // to do fewer comparisons, also swap the elements into their correct positions
    let mut pivot = unsafe { median_of_three(base, nel, width, comp) };

    let mut i = 1;
    let mut j = 1;
    let mut n = nel - 2;

    // use this to deal with the Dutch national flag problem
    while j <= n {
        let i_ptr = unsafe { base.add(i * width) };
        let j_ptr = unsafe { base.add(j * width) };
        let n_ptr = unsafe { base.add(n * width) };
        let pivot_ptr = unsafe { base.add(pivot * width) };

        let comparison = comp.compare(j_ptr as *const c_void, pivot_ptr as *const c_void);
        if comparison < 0 {
            unsafe { swap(i_ptr, j_ptr, width) };
            if i == pivot {
                pivot = j;
            }
            i += 1;
            j += 1;
        } else if comparison > 0 {
            unsafe { swap(j_ptr, n_ptr, width) };
            if n == pivot {
                pivot = j;
            }
            n -= 1;
        } else {
            j += 1;
        }
    }

    (i, n)
}

unsafe fn median_of_three<C: SortContext>(
    base: *mut c_char,
    nel: size_t,
    width: size_t,
    comp: &mut C,
) -> size_t {
    let pivot = nel / 2;

    let mid = unsafe { base.add(pivot * width) };
    let last = unsafe { base.add((nel - 1) * width) };
    if comp.compare(mid as *const c_void, base as *const c_void) < 0 {
        unsafe { swap(mid, base, width) };
    }
    if comp.compare(last as *const c_void, mid as *const c_void) < 0 {
        unsafe { swap(mid, last, width) };
        if comp.compare(mid as *const c_void, base as *const c_void) < 0 {
            unsafe { swap(mid, base, width) };
        }
    }

    pivot
}

#[inline]
unsafe fn swap(mut ptr1: *mut c_char, mut ptr2: *mut c_char, mut width: size_t) {
    use core::mem;

    const BUFSIZE: usize = 128;

    let mut buffer = mem::MaybeUninit::<[c_char; BUFSIZE]>::uninit();
    while width > 0 {
        let copy_size = BUFSIZE.min(width);
        let buf = buffer.as_mut_ptr().cast::<c_char>();

        unsafe {
            buf.copy_from_nonoverlapping(ptr1, copy_size);
            ptr1.copy_from_nonoverlapping(ptr2, copy_size);
            ptr2.copy_from_nonoverlapping(buf, copy_size);

            ptr1 = ptr1.add(copy_size);
            ptr2 = ptr2.add(copy_size);
        }
        width -= copy_size as size_t;
    }
}
