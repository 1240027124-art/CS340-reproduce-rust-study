/* c_cc { */
/// INTR character.
/// Send a `SIGINT` signal.
/// Canonical and Non-Canonical mode.
pub const VINTR: usize = 0;
/// QUIT character.
/// Send a `SIGQUIT` signal.
/// Canonical and Non-Canonical mode.
pub const VQUIT: usize = 1;
/// ERASE character.
/// Erases the previous not-yet-erased character, but does not erase past `EOF`
/// or beginning-of-line.
/// Canonical mode only.
pub const VERASE: usize = 2;
/// KILL character.
/// Erases the input since the last `EOF` or beginning-of-line.
/// Canonical mode only.
pub const VKILL: usize = 3;
/// EOF character.
/// End of file. Causes the pending tty buffer to be sent to the waiting user
/// program without waiting for end-of-line.
/// Canonical mode only.
pub const VEOF: usize = 4;
/// TIME value.
/// Timeout in decideconds for noncanonical read.
/// Non-Canonical mode only.
pub const VTIME: usize = 5;
/// MIN value.
/// Minimum number of characters for noncanonical read.
/// Non-Canonical mode only.
pub const VMIN: usize = 6;
/// START character.
/// Restarts output stopped by the STOP character.
/// Canonical and Non-Canonical mode.
pub const VSTART: usize = 8;
/// STOP character.
/// Stops the output until the START character is typed.
/// Canonical and Non-Canonical mode.
pub const VSTOP: usize = 9;
/// EOL character.
/// Additional end-of-line character.
/// Canonical mode only.
pub const VEOL: usize = 11;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// REPRINT character.
/// Reprints unread characters.
pub const VREPRINT: usize = 12;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// DISCARD character (not supported under Linux).
/// Toggles discarding pending output.
pub const VDISCARD: usize = 13;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// WERASE character.
/// Word erase.
pub const VWERASE: usize = 14;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// LNEXT character.
/// Literal next. Quotes the next input character, depriving it of a possible
/// special meaning.
pub const VLNEXT: usize = 15;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// EOL2 character.
/// Another end-of-line character.
pub const VEOL2: usize = 16;
/* } c_cc */

/* c_iflag { */
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// Map uppercase characters to lowercase on input.
pub const IUCLC: usize = 0o001_000;
/// Enable start/stop output control.
pub const IXON: usize = 0o002_000;
/// Enable start/stop input control.
pub const IXOFF: usize = 0o010_000;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// Ring bell when input queue is full.
///
/// # Implemetation
/// Linux acts as if this is always set.
pub const IMAXBEL: usize = 0o020_000;
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// Input is UTF8; this allows character-erase to be correctly performed in
/// cooked mode.
pub const IUTF8: usize = 0o040_000;
/* } c_iflag */

/* c_oflag { */
/// Non-POSIX, see <https://www.man7.org/linux/man-pages/man3/termios.3.html>.
///
/// Map lowercase characters to uppercase on output.
pub const OLCUC: usize = 0o000_002;
/// Map NL to CR-NL on output.
pub const ONLCR: usize = 0o000_004;
/// Select vertical-tab delays.
pub const VTDLY: usize = 0o040_000;
/// Vertical-tab delay type 0.
pub const VT0: usize = 0o000_000;
/// Vertical-tab delay type 1.
pub const VT1: usize = 0o040_000;
/* } c_oflag */

/* c_cflag { */
pub const B57600: usize = 0o010_001;
pub const B115200: usize = 0o010_002;
pub const B230400: usize = 0o010_003;
pub const B460800: usize = 0o010_004;
pub const B500000: usize = 0o010_005;
pub const B576000: usize = 0o010_006;
pub const B921600: usize = 0o010_007;
pub const B1000000: usize = 0o010_010;
pub const B1152000: usize = 0o010_011;
pub const B1500000: usize = 0o010_012;
pub const B2000000: usize = 0o010_013;
pub const B2500000: usize = 0o010_014;
pub const B3000000: usize = 0o010_015;
pub const B3500000: usize = 0o010_016;
pub const B4000000: usize = 0o010_017;

/// Character size.
pub const CSIZE: usize = 0o000_060;
/// 6 bits.
pub const CS6: usize = 0o000_020;
/// 7 bits.
pub const CS7: usize = 0o000_040;
/// 8 bits.
pub const CS8: usize = 0o000_060;

/// Send two stop bits, else one.
pub const CSTOPB: usize = 0o000_100;
/// Enable receiver.
pub const CREAD: usize = 0o000_200;
/// Parity enable.
pub const PARENB: usize = 0o000_400;
/// Odd parity, else even.
pub const PARODD: usize = 0o001_000;
/// Hang up on last close.
pub const HUPCL: usize = 0o002_000;
/// Ignore modem status lines.
pub const CLOCAL: usize = 0o004_000;
/* } c_clfag */

/* c_lflag { */
/// Enable signals.
pub const ISIG: usize = 0o000_001;
/// Canoncal input (erase and kill processing).
pub const ICANON: usize = 0o000_002;
/// Echo erase character as error-correcting backspace.
pub const ECHOE: usize = 0o000_020;
/// Echo KILL.
pub const ECHOK: usize = 0o000_040;
/// Echo NL.
pub const ECHONL: usize = 0o000_100;
/// Disable flush after interrupt or quit.
pub const NOFLSH: usize = 0o000_200;
/// Send `SIGTTOU` for background output.
pub const TOSTOP: usize = 0o000_400;
/// Enable extended input character processing.
pub const IEXTEN: usize = 0o100_000;
/* } c_lflag */
