use alloc::{ffi::CString, vec::Vec};
use core::ptr;

use crate::{
    header::errno::EBADF,
    platform::types::{c_char, c_int, c_uchar, mode_t, size_t},
};

#[derive(Debug, Clone)]
pub enum Action {
    Open {
        fd: c_int,
        path: CString,
        flag: c_int,
        mode: mode_t,
    },
    Close(c_int),
    Chdir(CString),
    FChdir(c_int),
    Dup2(c_int, c_int),
}

struct FileActions(Vec<Action>);

/// A spawn file actions object.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct posix_spawn_file_actions_t {
    __relibc_internal_size: [c_uchar; 24],
    __relibc_internal_align: size_t,
}

impl posix_spawn_file_actions_t {
    /// Adds an `Action` to `posix_spawn_file_actions_t`.
    pub fn add_action(&mut self, action: Action) {
        let v = ptr::from_mut(self).cast::<FileActions>();
        unsafe {
            (*v).0.push(action);
        }
    }
}

pub struct FileActionsIter {
    actions: posix_spawn_file_actions_t,
    curr: usize,
}

impl Iterator for FileActionsIter {
    type Item = Action;

    fn next(&mut self) -> Option<Self::Item> {
        let actions = unsafe {
            ptr::from_mut(&mut self.actions)
                .cast::<FileActions>()
                .as_ref()
                .unwrap()
        };
        let e = actions.0.get(self.curr)?;
        self.curr += 1;
        Some((*e).clone())
    }
}

impl IntoIterator for &posix_spawn_file_actions_t {
    type Item = Action;

    type IntoIter = FileActionsIter;

    fn into_iter(self) -> Self::IntoIter {
        FileActionsIter {
            actions: (*self),
            curr: 0,
        }
    }
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_init.html>.
///
/// Initializes the object referenced by `file_actions` to contain no file
/// actions for `posix_spawn()` or `posix_spawnp()` to perform.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
#[unsafe(no_mangle)]
pub extern "C" fn posix_spawn_file_actions_init(
    file_actions: *mut posix_spawn_file_actions_t,
) -> c_int {
    assert!(!file_actions.is_null(), "file_actions cannot be NULL");
    let v = Vec::new();
    let actions = FileActions(v);
    unsafe {
        ptr::write(file_actions.cast::<FileActions>(), actions);
    }
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_destroy.html>.
///
/// Destroys the object referenced by `file_actions`, effectively making it
/// uninitialized.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// If `file_actions` is not `NULL`, then it must be a pointer to a
/// `file_actions` object that was initialised by calling
/// `posix_spawn_file_actions_init()`.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_destroy(
    file_actions: *mut posix_spawn_file_actions_t,
) -> c_int {
    // TODO should we be returning EINVAL when `file_actions` is invalid?
    assert!(!file_actions.is_null(), "file_actions cannot be NULL");
    unsafe {
        let _ = *(file_actions.cast::<FileActions>());
    }
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_addopen.html>.
///
/// Adds an open action to a spawn file actions object.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// `path` must be a valid null-terminated C string.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_addopen(
    file_actions: *mut posix_spawn_file_actions_t,
    fildes: c_int,
    path: *const c_char,
    oflag: c_int,
    mode: mode_t,
) -> c_int {
    let file_actions = unsafe { file_actions.as_mut().expect("file_actions cannot be NULL") };
    if fildes < 0 {
        return EBADF;
    }
    file_actions.add_action(Action::Open {
        fd: fildes,
        path: if path.is_null() {
            CString::new("").unwrap()
        } else {
            unsafe { CString::from_raw(path.cast_mut()) }
        },
        flag: oflag,
        mode,
    });
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_addclose.html>.
///
/// Adds a close action to a spawn file actions object.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// `file_actions` must be initialised.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_addclose(
    file_actions: *mut posix_spawn_file_actions_t,
    fildes: c_int,
) -> c_int {
    let file_actions = unsafe { file_actions.as_mut().expect("file_actions cannot be NULL") };
    if fildes < 0 {
        return EBADF;
    }
    file_actions.add_action(Action::Close(fildes));
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_addchdir.html>.
///
/// Adds a chdir action to the object referenced by `file_actions` that shall
/// cause the working directory to be set to `path` (as if `chdir(path)` had
/// been called) when a new process is spawned using this file actions object.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// `file_actions` must be initialised and `path` must be a valid
/// null-terminated C string.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_addchdir(
    file_actions: *mut posix_spawn_file_actions_t,
    path: *const c_char,
) -> c_int {
    let file_actions = unsafe { file_actions.as_mut().expect("file_actions cannot be NULL") };
    file_actions.add_action(Action::Chdir(unsafe {
        if path.is_null() {
            CString::new("").unwrap()
        } else {
            CString::from_raw(path.cast_mut())
        }
    }));
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_addfchdir.html>.
///
/// Adds a fchdir action to the object referenced by `file_actions` that shall
/// cause the working directory to be set to `fildes` (as if `fchdir(fildes)`
/// had been called) when a new process is spawned using this file actions
/// object.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// `file_actions` must be initialised.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_addfchdir(
    file_actions: *mut posix_spawn_file_actions_t,
    fildes: c_int,
) -> c_int {
    let file_actions = unsafe { file_actions.as_mut().expect("file_actions cannot be NULL") };
    if fildes < 0 {
        return EBADF;
    }
    file_actions.add_action(Action::FChdir(fildes));
    0
}

/// See <https://pubs.opengroup.org/onlinepubs/9799919799/functions/posix_spawn_file_actions_adddup2.html>.
///
/// Adds a dup2 action to the object referenced by `file_actions` that shall
/// cause the file descriptor `fildes` to be duplicated as `newfildes` (as if
/// `dup2(fildes, newfildes)` had been called) when a new process is spawned
/// using this file actions object.
///
/// Upon success, returns `0`. Upon failure, an error number is returned.
///
/// # Panics
/// Panics if `file_actions` is `NULL`.
///
/// # Safety
/// `file_actions` must be initialised.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_spawn_file_actions_adddup2(
    file_actions: *mut posix_spawn_file_actions_t,
    fildes: c_int,
    newfildes: c_int,
) -> c_int {
    let file_actions = unsafe { file_actions.as_mut().expect("file_actions cannot be NULL") };
    if fildes < 0 || newfildes < 0 {
        return EBADF;
    }
    file_actions.add_action(Action::Dup2(fildes, newfildes));
    0
}
