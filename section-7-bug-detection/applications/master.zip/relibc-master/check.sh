#!/bin/bash

RED='\033[1;38;5;196m'
GREEN='\033[1;38;5;46m'
NC='\033[0m'

show_help() {
    echo "Usage: $(basename "$0") [OPTIONS]"
    echo ""
    echo "Description:"
    echo "  Wrapper for Makefile / Cargo to run checks or tests on Redox OS targets."
    echo ""
    echo "Options:"
    echo "  --test              Run 'make test' instead of 'make all'"
    echo "  --test=             Run single 'make test'"
    echo "  --cargo             Run 'cargo check' / 'cargo test' instead"
    echo "                         (note: cargo test is currently not maintained for relibc)"
    echo "  --host              Run the command on host (linux) target"
    echo "  --all-target        Run the command on all supported Redox architectures"
    echo "  --target=<target>   Override the target architecture (e.g., i586-unknown-redox; default: x86_64-unknown-redox)"
    echo "  --all-features      Run Cargo with the --all-features flag"
    echo "  --arch=<arch>       Override the target architecture using arch (e.g., i586)"
    echo "  --help              Show this help message"
    echo ""
    echo "Supported Targets:"
    for t in "${SUPPORTED_TARGETS[@]}"; do
        echo "  - $t"
    done
    echo "  - $(uname -m)-unknown-linux-gnu"
    echo ""
    echo "Environment:"
    echo "  TARGET              Sets the default target (overridden by --target)"
}

SUPPORTED_TARGETS=(
    "x86_64-unknown-redox"
    "i586-unknown-redox"
    "aarch64-unknown-redox"
    "riscv64gc-unknown-redox"
)

CURRENT_TARGET="${TARGET:-x86_64-unknown-redox}"
CHECK_ALL_TARGETS=false
ALL_FEATURES=false
CMD_ACTION="make"
CARGO_ACTION="check"
MAKE_ACTION="all"
TEST_BIN=""
IS_HOST=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --all-target)
            CHECK_ALL_TARGETS=true
            ;;
        --all-features)
            ALL_FEATURES=true
            ;;
        --test)
            MAKE_ACTION="test"
            CARGO_ACTION="test"
            ;;
        --test=*)
            TEST_BIN="${1#*=}"
            MAKE_ACTION="test-once"
            ;;
        --cargo)
            CMD_ACTION="cargo"
            ;;
        --clippy)
            CMD_ACTION="cargo"
            CARGO_ACTION="clippy"
            ;;
        --host)
            CURRENT_TARGET="$(uname -m)-unknown-linux-gnu"
            IS_HOST=1
            ;;
        --target=*)
            CURRENT_TARGET="${1#*=}"
            ;;
        --arch=*)
            CURRENT_TARGET="${1#*=}-unknown-redox"
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            echo -e "${RED}Error: Unknown option '$1'${NC}"
            show_help
            exit 1
            ;;
    esac
    shift
done

if ! command -v cbindgen &> /dev/null; then
    echo "Error: 'cbindgen' CLI not found."
    echo "Please install it: cargo install cbindgen"
    exit 1
fi

if [ "$IS_HOST" -eq 0 ]; then
    if ! command -v redoxer &> /dev/null; then
        echo "Error: 'redoxer' CLI not found."
        echo "Please install it: cargo install redoxer"
        exit 1
    fi

    if ! command -v fusermount &> /dev/null; then
        echo "Error: 'fusermount' CLI not found."
        echo "Please install it using your package manager"
        exit 1
    fi

    if ! command -v rsync &> /dev/null; then
        echo "Error: 'rsync' CLI not found."
        echo "Please install it using your package manager"
        exit 1
    fi
fi

run() {
    export TARGET=$1
    REDOXER_ENV="redoxer env"
    if [ "$IS_HOST" -eq 0 ]; then
        redoxer toolchain || { echo -e "${RED}Fail: redoxer toolchain for: $target.${NC}" && exit 1; }
        export CARGO_TEST="redoxer"
        export TEST_RUNNER="redoxer exec --folder ../../sysroot/$TARGET/:/usr --folder . --"

        MAKE_ACTION="$MAKE_ACTION IS_REDOX=1"
    else
        REDOXER_ENV=""
    fi

    if [ "$TEST_BIN" != "" ]; then
        MAKE_ACTION="$MAKE_ACTION TESTBIN=bins_dynamic/$TEST_BIN"
    fi

    if [ "$CMD_ACTION" == "make" ]; then
        CMD_OPT="-j $(nproc) $MAKE_ACTION"
    else
        CMD_OPT="$CARGO_ACTION --target=$TARGET"
    fi

    if [ "$ALL_FEATURES" = true ]; then
        CMD_OPT="$CMD_OPT --all-features"
    fi

    echo "----------------------------------------"
    echo "Running $REDOXER_ENV $CMD_ACTION $CMD_OPT for: $TARGET"

    if $REDOXER_ENV $CMD_ACTION $CMD_OPT; then
        return 0
    else
        echo -e "${RED}Fail: $CMD_ACTION $CMD_OPT for $TARGET failed.${NC}"
        return 1
    fi
}

if [ "$CHECK_ALL_TARGETS" = true ]; then
    echo "Running $CMD_ACTION for all supported Redox targets..."

    has_error=false

    for target in "${SUPPORTED_TARGETS[@]}"; do
        if ! run "$target"; then
            has_error=true
        fi
    done

    echo "----------------------------------------"
    if [ "$has_error" = true ]; then
        echo -e "${RED}Summary: One or more targets failed.${NC}"
        exit 1
    else
        echo -e "${GREEN}Summary: All targets passed!${NC}"
        exit 0
    fi
else
    if run "$CURRENT_TARGET"; then
        echo -e "${GREEN}Success: $CARGO_ACTION for $CURRENT_TARGET passed.${NC}"
        exit 0
    else
        exit 1
    fi
fi
